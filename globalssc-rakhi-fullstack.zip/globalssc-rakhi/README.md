# GLOBALSSC — Rakhi Special 2040 ("Any Website ₹3,999")

A full lead-generation site: futuristic frontend + real backend (SQLite database,
email alerts, WhatsApp notifications, admin dashboard).

```
globalssc-rakhi/
├── public/
│   └── index.html        ← the frontend (served by the backend)
├── server/
│   ├── server.js          ← Express API + static file server
│   ├── db.js               ← SQLite storage
│   ├── validate.js         ← server-side input validation/sanitization
│   ├── email.js             ← SMTP email notifications
│   ├── whatsapp.js          ← WhatsApp Cloud API notifications
│   ├── package.json
│   └── .env.example
└── README.md
```

## 1. Run it locally

```bash
cd server
cp .env.example .env      # then fill in real values (see below)
npm install
npm start
```

Open **http://localhost:3000** — that's the full site, form, and WhatsApp buttons.
Open the **Admin** button (bottom-left) and enter your `ADMIN_KEY` to see enquiries.

## 2. What's real out of the box

- **Database:** every submission is saved to a real SQLite file (`server/enquiries.db`),
  not browser storage. Survives restarts.
- **Validation:** name, 10-digit Indian phone, business type, and requirements are
  validated and sanitized **on the server**, not just in the browser — this is what
  makes the API endpoint actually secure against bad or malicious input.
- **Rate limiting:** the public `/api/enquiry` endpoint is capped at 8 submissions
  per 10 minutes per IP to block spam/abuse.
- **Admin dashboard:** protected by an `x-admin-key` header checked against your
  `ADMIN_KEY` — only someone with the key can read enquiries.
- **Click-to-WhatsApp:** every WhatsApp button opens `wa.me` with the enquiry
  pre-filled — no API key needed, works immediately.

## 3. Turning on email notifications

Edit `.env`:

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-16-character-app-password
NOTIFY_EMAIL_TO=team@globalssc.com
```

For Gmail: turn on 2-Step Verification, then create an **App Password**
(myaccount.google.com → Security → App passwords) — use that, not your normal
password. Any SMTP provider works the same way (Zoho, Resend, Brevo, SendGrid).

## 4. Turning on automatic WhatsApp notifications (to your team)

This uses Meta's **WhatsApp Cloud API** to auto-notify GLOBALSSC's own number
the moment a lead comes in (separate from the customer-facing wa.me button,
which already works with no setup).

1. Go to [developers.facebook.com](https://developers.facebook.com) → create an app → add the **WhatsApp** product.
2. In the WhatsApp → API Setup screen, you'll get a **temporary access token** and a **Phone number ID** — copy both.
3. Add your team's WhatsApp number as a **recipient** for testing (Meta requires this in dev mode).
4. Fill `.env`:
   ```
   WHATSAPP_CLOUD_API_TOKEN=your-token
   WHATSAPP_PHONE_NUMBER_ID=your-phone-number-id
   WHATSAPP_ADMIN_NUMBER=916309579202
   ```
5. For production (permanent token, no 24-hour message-window restriction),
   verify your Meta Business and request a permanent token + an approved
   message **template** — Meta blocks business-initiated free-text messages
   outside a 24-hour customer conversation window.

If these variables are left blank, the server simply skips WhatsApp
notification and logs a warning — nothing breaks.

## 5. Deploying it for real

GitHub Pages **cannot** run this — it only hosts static files, and this app
needs a live Node process for the database and notifications. Use one of:

- **Render.com** (free tier): New → Web Service → connect your GitHub repo →
  root directory `server` → build command `npm install` → start command `npm start`
  → add your `.env` values under Environment.
- **Railway.app**: similar one-click Node deploy, same env vars.
- **A VPS** (e.g. DigitalOcean): `git clone`, `npm install`, run with `pm2 start server.js`
  behind Nginx for HTTPS.

Push this whole folder to GitHub first, then connect that repo to Render/Railway —
GitHub just hosts the code; Render/Railway actually runs it.

## 6. Security notes

- Change `ADMIN_KEY` in `.env` to a long random string before deploying —
  never leave the example value in production.
- Never commit `.env` to GitHub (see `.gitignore`).
- All user input is escaped before storage/display to prevent injected HTML/script content.
